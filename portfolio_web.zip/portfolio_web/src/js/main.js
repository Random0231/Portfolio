// Animate drive items on scroll
const driveItems = document.querySelectorAll('.drive-item');
const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
};

const driveObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animation = 'fadeInUp 1s ease-out forwards';
            driveObserver.unobserve(entry.target);
        }
    });
}, observerOptions);

driveItems.forEach(item => {
    driveObserver.observe(item);
});

// Drive Items Click Animations
document.addEventListener('DOMContentLoaded', () => {
    const driveItems = document.querySelectorAll('.drive-item');
    
    driveItems.forEach(item => {
        item.addEventListener('click', () => {
            // Remove clicked class from all items
            driveItems.forEach(i => i.classList.remove('clicked'));
            
            // Add clicked class to current item
            item.classList.add('clicked');
            
            // Remove clicked class after animation completes
            setTimeout(() => {
                item.classList.remove('clicked');
            }, 1000);
        });
    });
});

// Initialize particles.js
document.addEventListener('DOMContentLoaded', () => {
    particlesJS('particles-js', {
        particles: {
            number: {
                value: 80,
                density: {
                    enable: true,
                    value_area: 800
                }
            },
            color: {
                value: '#2563eb'
            },
            shape: {
                type: 'circle'
            },
            opacity: {
                value: 0.5,
                random: false
            },
            size: {
                value: 3,
                random: true
            },
            line_linked: {
                enable: true,
                distance: 150,
                color: '#2563eb',
                opacity: 0.4,
                width: 1
            },
            move: {
                enable: true,
                speed: 6,
                direction: 'none',
                random: false,
                straight: false,
                out_mode: 'out',
                bounce: false
            }
        },
        interactivity: {
            detect_on: 'canvas',
            events: {
                onhover: {
                    enable: true,
                    mode: 'grab'
                },
                onclick: {
                    enable: true,
                    mode: 'push'
                },
                resize: true
            }
        },
        retina_detect: true
    });

    // Custom cursor movement
    const cursor = document.querySelector('.cursor');
    const cursorBall = cursor.querySelector('.cursor__ball');

    let mouseX = 0;
    let mouseY = 0;
    let ballX = 0;
    let ballY = 0;

    gsap.to({}, 0.016, {
        repeat: -1,
        onRepeat: function() {
            ballX += (mouseX - ballX) / 8;
            ballY += (mouseY - ballY) / 8;
            gsap.set(cursor, {
                x: mouseX,
                y: mouseY
            });
            gsap.set(cursorBall, {
                x: ballX,
                y: ballY
            });
        }
    });

    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });

    // Theme switcher functionality
    const themeBtns = document.querySelectorAll('.theme-btn');
    const body = document.body;

    // Get theme from localStorage or default to 'light'
    const savedTheme = localStorage.getItem('theme') || 'light';
    body.setAttribute('data-theme', savedTheme);
    updateActiveThemeButton(savedTheme);

    // Update particles color based on theme
    function updateParticlesColor(theme) {
        if (window.pJSDom && window.pJSDom[0]) {
            const particles = window.pJSDom[0].pJS.particles;
            if (theme === 'black' || theme === 'glass') {
                particles.color.value = '#60a5fa';
                particles.line_linked.color = '#60a5fa';
            } else {
                particles.color.value = '#2563eb';
                particles.line_linked.color = '#2563eb';
            }
            window.pJSDom[0].pJS.fn.particlesRefresh();
        }
    }

    // Theme button click handlers
    themeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const theme = btn.getAttribute('data-theme');
            body.setAttribute('data-theme', theme);
            localStorage.setItem('theme', theme);
            updateActiveThemeButton(theme);
            updateParticlesColor(theme);
        });
    });

    // Initialize particles color based on current theme
    updateParticlesColor(savedTheme);

    function updateActiveThemeButton(theme) {
        themeBtns.forEach(btn => {
            if (btn.getAttribute('data-theme') === theme) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
    }

    // Add hover effect to interactive elements
    const interactiveElements = document.querySelectorAll('a, button, .interactive');
    interactiveElements.forEach(el => {
        el.addEventListener('mouseenter', () => {
            gsap.to('.cursor__ball circle', {
                scale: 4,
                duration: 0.3
            });
        });
        
        el.addEventListener('mouseleave', () => {
            gsap.to('.cursor__ball circle', {
                scale: 1,
                duration: 0.3
            });
        });
    });
});

// ... existing code ...